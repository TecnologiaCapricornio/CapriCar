/* Autenticação local, contas, permissões e navegação por abas */
/* As contas deste protótipo são persistidas somente neste navegador. */
function getCurrentUser(){
  try{
    const data = localStorage.getItem(USER_KEY);
    return data ? JSON.parse(data) : null;
  }catch(e){
    return null;
  }
}

function setCurrentUser(user){
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

function clearCurrentUser(){
  localStorage.removeItem(USER_KEY);
}

function normalizeUserPermissions(permissions){
  const source = permissions || {};
  return {
    reservations:source.reservations === true,
    branches:source.branches === true,
    fleet:source.fleet === true,
    maintenance:source.maintenance === true,
    blocks:source.blocks === true,
    reports:source.reports === true,
    audit:source.audit === true,
    rules:source.rules === true,
    users:source.users === true,
    integrations:source.integrations === true
  };
}

function normalizeSystemUser(account){
  return {
    id:String(account.id || ('user-' + Date.now())),
    username:String(account.username || '').trim().toLowerCase(),
    nome:String(account.nome || account.username || '').trim(),
    email:String(account.email || '').trim(),
    centroCusto:String(account.centroCusto || '').trim(),
    role:account.role === 'admin' ? 'admin' : 'user',
    active:account.active !== false,
    authProvider:account.authProvider === 'entra' ? 'entra' : 'local',
    permissions:normalizeUserPermissions(account.permissions),
    // Só vem preenchido para quem tem a permissão "Usuários" (o servidor já
    // filtra) - null/undefined aqui só significa "sem CNH cadastrada ou sem
    // permissão pra ver", nunca é tratado como erro.
    cnh:account.cnh || null,
    cnhStatus:account.cnhStatus || 'ausente',
    cnhDiasRestantes:account.cnhDiasRestantes == null ? null : Number(account.cnhDiasRestantes)
  };
}

function getSystemUsers(){
  try{
    const parsed = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    return Array.isArray(parsed) ? parsed.map(normalizeSystemUser) : [];
  }catch(e){
    return [];
  }
}

function saveSystemUsers(accounts){
  const normalized = accounts.map(normalizeSystemUser);
  localStorage.setItem(USERS_KEY, JSON.stringify(normalized));
  return normalized;
}

function ensureSystemUsers(){
  return getSystemUsers();
}

function accountToSession(account){
  return {
    id:account.id,
    username:account.username,
    nome:account.nome,
    email:account.email || '',
    isAdmin:account.role === 'admin',
    role:account.role,
    permissions:normalizeUserPermissions(account.permissions)
  };
}

function isAdmin(){
  const user = getCurrentUser();
  return !!(user && (user.isAdmin === true || user.role === 'admin'));
}

function hasManagementPermission(permission){
  if(isAdmin()) return true;
  const user = getCurrentUser();
  return !!(user && user.permissions && user.permissions[permission] === true);
}

function canAccessManagement(){
  return isAdmin() || ['reservations', 'branches', 'fleet', 'maintenance', 'blocks', 'reports', 'audit', 'rules', 'users', 'integrations'].some(hasManagementPermission);
}

function canManageReservations(){
  return hasManagementPermission('reservations');
}

function canManageBranches(){
  return hasManagementPermission('branches');
}

function canManageFleet(){
  return hasManagementPermission('fleet');
}

function canManageMaintenance(){
  return hasManagementPermission('maintenance');
}

function canManageBlocks(){
  return hasManagementPermission('blocks');
}

function canViewReports(){
  return hasManagementPermission('reports');
}

function canViewAudit(){
  return hasManagementPermission('audit');
}

function canManageRules(){
  return hasManagementPermission('rules');
}

function canManageUsers(){
  return hasManagementPermission('users');
}

function canManageIntegrations(){
  return hasManagementPermission('integrations');
}

function canAccessAdminSection(section){
  if(isAdmin()) return true;
  // "reservas" mostra a lista operacional (permissão "reservations") e os
  // indicadores da frota (permissão "reports", mesmos indicadores da aba
  // "Relatórios") - qualquer uma das duas dá acesso à aba; dentro dela, cada
  // bloco continua checando sua própria permissão (ver renderAdminTab em
  // js/admin.js e renderIndicators em js/management-indicators.js). A aba
  // "Relatórios" (filtros, resumo, exportação) continua exigindo "reports"
  // à parte, no bloco genérico abaixo.
  if(section === 'reservas'){
    return hasManagementPermission('reservations') || hasManagementPermission('reports');
  }
  const permissionBySection = {
    locais:'branches',
    veiculos:'fleet',
    bloqueios:'blocks',
    manutencao:'maintenance',
    auditoria:'audit',
    relatorios:'reports',
    regras:'rules',
    usuarios:'users',
    integracoes:'integrations'
  };
  return !!permissionBySection[section] && hasManagementPermission(permissionBySection[section]);
}

const loginScreen = document.getElementById('loginScreen');
const appScreen = document.getElementById('appScreen');
const loginForm = document.getElementById('loginForm');
const loginNomeInput = document.getElementById('loginNome');
const loginEmailInput = document.getElementById('loginEmail');
const ssoDivider = document.getElementById('ssoDivider');
const ssoLoginBtn = document.getElementById('ssoLoginBtn');
const loginMethodsUnavailable = document.getElementById('loginMethodsUnavailable');

const headerUserName = document.getElementById('headerUserName');
const avatarInitials = document.getElementById('avatarInitials');
const solicitanteHint = document.getElementById('solicitanteHint');
const adminTabBtn = document.getElementById('adminTabBtn');

const profileBtn = document.getElementById('profileBtn');
const profileMenuCenter = document.getElementById('profileMenuCenter');
const profileMenuPanel = document.getElementById('profileMenuPanel');
const profileMenuCnhBtn = document.getElementById('profileMenuCnhBtn');
const profileModal = document.getElementById('profileModal');
const profileCloseBtn = document.getElementById('profileCloseBtn');
const profileAvatarLg = document.getElementById('profileAvatarLg');
const profileName = document.getElementById('profileName');
const logoutBtn = document.getElementById('logoutBtn');

function configureManagementPanel(){
  const orderedSections = ['reservas','locais','veiculos','bloqueios','manutencao','auditoria','relatorios','regras','integracoes','usuarios'];
  const firstAllowedSection = orderedSections.find(canAccessAdminSection) || 'reservas';
  document.querySelectorAll('.admin-section-btn').forEach(btn => {
    const section = btn.getAttribute('data-admin-section');
    btn.classList.toggle('hidden', !canAccessAdminSection(section));
    btn.classList.toggle('active', section === firstAllowedSection);
  });
  document.querySelectorAll('.admin-section-panel').forEach(panel => {
    panel.classList.toggle('hidden', panel.id !== 'admin-section-' + firstAllowedSection);
  });
  const title = document.getElementById('managementPanelTitle');
  if(title){
    title.textContent = isAdmin() ? 'Painel de Administração' : 'Painel de Gestão';
  }
  const newReservationBtn = document.getElementById('adminNovaReservaBtn');
  if(newReservationBtn){
    newReservationBtn.textContent = isAdmin() ? 'Nova reserva (como admin)' : 'Nova reserva (gestão)';
  }
}

function setLoginError(fieldId, message){
  const field = document.getElementById('field-' + fieldId);
  const errorEl = document.getElementById('error-' + fieldId);
  if(message){
    field.classList.add('invalid');
    errorEl.textContent = message;
  } else {
    field.classList.remove('invalid');
    errorEl.textContent = '';
  }
}

function showApp(user){
  loginScreen.classList.add('hidden');
  appScreen.classList.remove('hidden');
  headerUserName.textContent = user.nome;
  avatarInitials.textContent = initials(user.nome);
  profileName.textContent = user.nome;
  profileAvatarLg.textContent = initials(user.nome);
  updateSolicitanteHint();
  adminTabBtn.textContent = isAdmin() ? 'Admin' : 'Gestão';
  adminTabBtn.setAttribute('data-mobile-label', isAdmin() ? 'Admin' : 'Gestão');
  adminTabBtn.classList.toggle('hidden', !canAccessManagement());
  configureManagementPanel();
  switchTab('minhas');
  renderMyReservations();
  renderCarSelector();
  renderMainCalendar();
  renderAvailableRides();
  initializeNotifications();
  loadDriverLicense();
}

function showLogin(){
  appScreen.classList.add('hidden');
  loginScreen.classList.remove('hidden');
  loginForm.reset();
  adminTabBtn.classList.add('hidden');
}

loginForm.addEventListener('submit', async function(e){
  e.preventDefault();
  setLoginError('loginNome', '');
  setLoginError('loginEmail', '');

  const nome = loginNomeInput.value.trim();
  const senha = loginEmailInput.value.trim();
  let valid = true;

  if(!nome){
    setLoginError('loginNome', 'Informe seu usuário.');
    valid = false;
  }
  if(!senha){
    setLoginError('loginEmail', 'Informe sua senha.');
    valid = false;
  }

  if(!valid) return;

  let user;
  try{
    const authentication = await apiRequest('/api/auth/login', {
      method:'POST',
      body:{ username:nome, password:senha }
    });
    user = accountToSession(authentication.user);
    setCurrentUser(user);
  }catch(error){
    clearCurrentUser();
    setLoginError('loginEmail', error.message || 'Usuário ou senha incorretos.');
    return;
  }

  // A autenticação já foi aceita pelo servidor neste ponto - uma falha ao
  // sincronizar os dados não deve derrubar a sessão nem aparecer como se
  // fosse usuário ou senha incorretos.
  try{
    await hydrateDatabaseState();
  }catch(error){
    console.error('Falha ao sincronizar dados após o login:', error);
  }
  showApp(user);
});

ssoLoginBtn.addEventListener('click', function(){
  window.location.href = '/api/auth/sso/login';
});

// Este bloco depende de APIs de navegador (fetch/URLSearchParams/history)
// que nao existem no sandbox usado por tests/permissions.test.js para
// carregar este arquivo - por isso so roda em um browser de verdade.
if(typeof window !== 'undefined' && typeof URLSearchParams !== 'undefined'){
  // Consulta quais metodos de login estao disponiveis no servidor - a
  // variavel LOGIN_METHOD (.env, ver server/config.js) decide se cada um
  // aparece, independente de o Entra ID estar configurado ou nao. O
  // formulario local comeca visivel (cobre o caso mais comum sem esperar a
  // resposta); so e escondido se o servidor disser que esta desativado.
  (async function checkSsoAvailability(){
    try{
      const status = await apiRequest('/api/auth/sso/status');
      const showSso = status.enabled === true;
      const showLocal = status.localEnabled !== false;
      loginForm.classList.toggle('hidden', !showLocal);
      ssoLoginBtn.classList.toggle('hidden', !showSso);
      ssoDivider.classList.toggle('hidden', !(showSso && showLocal));
      loginMethodsUnavailable.classList.toggle('hidden', showSso || showLocal);
    }catch(error){
      console.error('Falha ao consultar status do login via Microsoft:', error);
    }
  })();

  // O callback do SSO (server/routes/sso.js) redireciona de volta para "/"
  // com ?error=... quando o login via Microsoft nao pode ser concluido.
  (function showSsoErrorIfAny(){
    const params = new URLSearchParams(window.location.search);
    const code = params.get('error');
    if(!code) return;
    const messages = {
      sso_denied:'Login via Microsoft cancelado.',
      sso_state:'Sessão de login via Microsoft expirada. Tente novamente.',
      sso_conflict:'Já existe uma conta local com esse usuário. Fale com um administrador.',
      sso_domain_denied:'Este domínio não tem acesso ao CapriCar.',
      sso_failed:'Não foi possível concluir o login via Microsoft.',
      sso_disabled:'Login via Microsoft não está configurado.'
    };
    setLoginError('loginEmail', messages[code] || 'Não foi possível concluir o login via Microsoft.');
    window.history.replaceState({}, '', window.location.pathname);
  })();
}

function closeProfileMenu(){
  profileMenuPanel.classList.add('hidden');
  profileBtn.setAttribute('aria-expanded', 'false');
}

function openProfileCnhModal(){
  profileModal.classList.remove('hidden');
  // O seletor de data da CNH só pode ser criado depois de js/modals.js ter
  // carregado, por isso a inicialização é sob demanda (ver js/driver-license.js).
  if(typeof ensureCnhDatePicker === 'function') ensureCnhDatePicker();
}

// Clicar no nome/avatar abre um menu ("Minha CNH", "Sair") em vez da CNH
// direto - mesmo padrão do sino de notificações (js/notifications.js).
profileBtn.addEventListener('click', function(event){
  event.stopPropagation();
  const opening = profileMenuPanel.classList.contains('hidden');
  profileMenuPanel.classList.toggle('hidden', !opening);
  profileBtn.setAttribute('aria-expanded', opening ? 'true' : 'false');
});

profileMenuCnhBtn.addEventListener('click', function(){
  closeProfileMenu();
  openProfileCnhModal();
});

document.addEventListener('click', function(event){
  if(profileMenuCenter && !profileMenuCenter.contains(event.target)) closeProfileMenu();
});

document.addEventListener('keydown', function(event){
  if(event.key === 'Escape' && !profileMenuPanel.classList.contains('hidden')){
    closeProfileMenu();
    profileBtn.focus();
  }
});

profileCloseBtn.addEventListener('click', function(){
  profileModal.classList.add('hidden');
});

profileModal.addEventListener('click', function(e){
  if(e.target === profileModal) profileModal.classList.add('hidden');
});

logoutBtn.addEventListener('click', async function(){
  closeProfileMenu();
  try{
    await apiRequest('/api/auth/logout', { method:'POST' });
  }catch(error){
    console.error('Falha ao encerrar sessão no servidor:', error);
  }
  databaseHydrated = false;
  stopNotifications();
  clearCurrentUser();
  profileModal.classList.add('hidden');
  showLogin();
});

/* =========================================================
   Navegação por abas
   ========================================================= */
const tabsNav = document.getElementById('tabsNav');
const mobileNavToggle = document.getElementById('mobileNavToggle');
const mobileNavCurrent = document.getElementById('mobileNavCurrent');
const myNewReservationBtn = document.getElementById('myNewReservationBtn');
const panels = {
  nova: document.getElementById('panel-nova'),
  calendario: document.getElementById('panel-calendario'),
  minhas: document.getElementById('panel-minhas'),
  caronas: document.getElementById('panel-caronas'),
  admin: document.getElementById('panel-admin')
};
let tabRefreshSequence = 0;

function initializeTabAccessibility(){
  if(!tabsNav || typeof tabsNav.setAttribute !== 'function') return;
  tabsNav.setAttribute('role', 'tablist');
  tabsNav.setAttribute('aria-label', 'Navegação principal');
  tabsNav.querySelectorAll('.tab-btn').forEach(button => {
    const name = button.getAttribute('data-tab');
    const panel = panels[name];
    button.id = 'main-tab-' + name;
    button.setAttribute('role', 'tab');
    button.setAttribute('aria-controls', panel.id);
    button.setAttribute('aria-selected', button.classList.contains('active') ? 'true' : 'false');
    button.tabIndex = button.classList.contains('active') ? 0 : -1;
    panel.setAttribute('role', 'tabpanel');
    panel.setAttribute('aria-labelledby', button.id);
    panel.tabIndex = 0;
  });
}

function setMobileNavOpen(open){
  const expanded = !!open;
  tabsNav.classList.toggle('mobile-collapsed', !expanded);
  mobileNavToggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
  mobileNavToggle.setAttribute(
    'aria-label',
    (expanded ? 'Fechar' : 'Abrir') + ' menu de navegação. Tela atual: ' + mobileNavCurrent.textContent
  );
}

function renderCurrentTabData(tabName, refreshedFromServer){
  if(tabName === 'minhas') renderMyReservations();
  if(tabName === 'calendario'){
    renderCarSelector();
    renderMainCalendar();
  }
  if(tabName === 'caronas') renderAvailableRides();
  if(tabName === 'nova' && refreshedFromServer){
    populateCarroOptions(true);
    populateDestinoOptions();
    refreshDatePickers();
    refreshAvailableTimeOptions();
  }
  if(tabName === 'admin'){
    const activeSection = document.querySelector('.admin-section-btn.active:not(.hidden)');
    if(activeSection && typeof renderAdminSection === 'function'){
      renderAdminSection(activeSection.getAttribute('data-admin-section'));
    }
  }
}

async function refreshTabFromServer(tabName, refreshSequence){
  if(!getCurrentUser() || typeof hydrateDatabaseState !== 'function') return;
  try{
    if(typeof databaseSyncQueue !== 'undefined') await databaseSyncQueue.catch(() => {});
    await hydrateDatabaseState();
    const activeButton = tabsNav.querySelector('.tab-btn.active');
    const activeTab = activeButton ? activeButton.getAttribute('data-tab') : '';
    if(refreshSequence !== tabRefreshSequence || activeTab !== tabName) return;
    renderCurrentTabData(tabName, true);
  }catch(error){
    console.warn('Não foi possível atualizar a aba automaticamente:', error);
  }
}

function switchTab(tabName){
  if(tabName === 'admin' && !canAccessManagement()) return;
  if(tabName === 'nova'){
    const pendingReturn = getPendingReturnReservation(getCurrentUser());
    if(pendingReturn){
      showSiteAlert(pendingReturnReservationMessage(pendingReturn), {
        title:'Devolução pendente',
        type:'warning'
      });
      tabName = 'minhas';
    } else if(
      typeof getLicenseState === 'function' && getLicenseState() !== null &&
      typeof userCanDrive === 'function' && !userCanDrive()
    ){
      // Sem CNH válida a tela nem chega a abrir - mesmo padrão da devolução
      // pendente logo acima, e não só um aviso com o formulário liberado
      // por trás dele.
      showCnhRequiredAlert();
      tabName = 'minhas';
    } else if(typeof resetReservationForm === 'function'){
      // Reseta o formulário inteiro (campos + assistente por etapas) sempre
      // que a aba é aberta - inclusive pela barra de abas, não só pelo
      // atalho "+ Nova reserva". Sem isto, um rascunho não confirmado (ou
      // uma etapa avançada) ficava preso na próxima visita: os campos
      // continuavam com os valores antigos, e a etapa "presa" no atributo
      // data-mobile-step escondia campos já preenchidos (ver
      // resetReservationForm em js/reservations.js).
      resetReservationForm();
    }
  }
  appScreen.classList.toggle('calendar-mobile-view', tabName === 'calendario');
  Object.keys(panels).forEach(key => {
    panels[key].classList.toggle('hidden', key !== tabName);
  });
  tabsNav.querySelectorAll('.tab-btn').forEach(btn => {
    const selected = btn.getAttribute('data-tab') === tabName;
    btn.classList.toggle('active', selected);
    btn.setAttribute('aria-selected', selected ? 'true' : 'false');
    btn.tabIndex = selected ? 0 : -1;
  });
  const selectedButton = tabsNav.querySelector('.tab-btn[data-tab="' + tabName + '"]');
  if(selectedButton){
    mobileNavCurrent.textContent = selectedButton.textContent.trim();
    mobileNavToggle.setAttribute('aria-label',
      'Abrir menu de navegação. Tela atual: ' + mobileNavCurrent.textContent);
  }
  if(window.matchMedia('(max-width:480px)').matches){
    setMobileNavOpen(false);
  }
  renderCurrentTabData(tabName, false);
  const refreshSequence = ++tabRefreshSequence;
  refreshTabFromServer(tabName, refreshSequence);
  refreshNotifications();
}

myNewReservationBtn.addEventListener('click', function(){
  switchTab('nova');
  if(typeof window.scrollTo === 'function'){
    window.scrollTo({ top:0, behavior:'smooth' });
  }
});

mobileNavToggle.addEventListener('click', function(){
  setMobileNavOpen(this.getAttribute('aria-expanded') !== 'true');
});

tabsNav.addEventListener('click', function(e){
  const btn = e.target.closest('.tab-btn');
  if(!btn) return;
  switchTab(btn.getAttribute('data-tab'));
});

tabsNav.addEventListener('keydown', function(e){
  if(!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
  const buttons = [...tabsNav.querySelectorAll('.tab-btn:not(.hidden)')];
  const currentIndex = buttons.indexOf(document.activeElement);
  if(currentIndex < 0) return;
  e.preventDefault();
  let nextIndex = currentIndex;
  if(e.key === 'Home') nextIndex = 0;
  else if(e.key === 'End') nextIndex = buttons.length - 1;
  else nextIndex = (currentIndex + (e.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length;
  buttons[nextIndex].focus();
  switchTab(buttons[nextIndex].getAttribute('data-tab'));
});

document.addEventListener('keydown', function(e){
  if(e.key === 'Escape') setMobileNavOpen(false);
});

initializeTabAccessibility();
