/* Gestão — retirada, devolução e fotos de operação */

/* Gestão de frota, bloqueios, operação, auditoria e relatórios */

function operationPhotoFilename(photo, index, phaseLabel) {
  const original = String(photo && photo.nome || '').trim();
  const fallbackExtension = String(photo && photo.tipo || '').includes('png') ? '.png' : '.jpg';
  const fallback = 'foto-' + String(phaseLabel || 'veiculo').toLowerCase() + '-' +
    (index + 1) + fallbackExtension;
  return (original || fallback)
    .replace(/[\\/:*?"<>|]+/g, '-')
    .replace(/\s+/g, ' ')
    .slice(0, 120);
}

function renderOperationPhoto(photo, index, phaseLabel) {
  const dataUrl = String(photo && photo.dados || '');
  const protectedUrl = String(photo && photo.url || '');
  const source = dataUrl.startsWith('data:image/')
    ? dataUrl
    : (protectedUrl.startsWith('/api/reservations/') ? protectedUrl : '');
  if (!source) return '';
  const filename = operationPhotoFilename(photo, index, phaseLabel);
  const safeSource = escapeHTML(source);
  const downloadSource = escapeHTML(protectedUrl
    ? protectedUrl + (protectedUrl.includes('?') ? '&' : '?') + 'download=1'
    : source);
  const safeFilename = escapeHTML(filename);
  return '<div class="operation-photo-card">' +
    '<a class="operation-photo-preview" href="' + safeSource + '" target="_blank" rel="noopener" ' +
    'aria-label="Abrir ' + safeFilename + '">' +
    '<img src="' + safeSource + '" alt="' + safeFilename + '">' +
    '</a>' +
    '<a class="operation-photo-download" href="' + downloadSource + '" download="' + safeFilename + '">' +
    '&#8595; Baixar imagem' +
    '</a>' +
    '</div>';
}

function operationPhotoBlob(dataUrl) {
  const match = dataUrl.match(/^data:([^;,]+);base64,(.+)$/);
  if (!match) return null;

  try {
    const binary = atob(match[2]);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
    return new Blob([bytes], { type: match[1] });
  } catch (error) {
    console.error('Nao foi possivel processar a foto.', error);
    return null;
  }
}

function downloadOperationPhoto(link) {
  const blob = operationPhotoBlob(String(link.getAttribute('href') || ''));
  if (!blob) return false;

  try {
    const objectUrl = URL.createObjectURL(blob);
    const temporaryLink = document.createElement('a');
    temporaryLink.href = objectUrl;
    temporaryLink.download = link.getAttribute('download') || 'foto-veiculo.jpg';
    temporaryLink.hidden = true;
    document.body.appendChild(temporaryLink);
    temporaryLink.click();
    temporaryLink.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    return true;
  } catch (error) {
    console.error('Nao foi possivel baixar a foto.', error);
    return false;
  }
}

function openOperationPhoto(link) {
  const blob = operationPhotoBlob(String(link.getAttribute('href') || ''));
  if (!blob) return false;
  const objectUrl = URL.createObjectURL(blob);
  window.open(objectUrl, '_blank', 'noopener');
  setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
  return true;
}

document.addEventListener('click', function (event) {
  const downloadLink = event.target.closest('.operation-photo-download');
  if (downloadLink) {
    if (!String(downloadLink.getAttribute('href') || '').startsWith('data:image/')) return;
    event.preventDefault();
    downloadOperationPhoto(downloadLink);
    return;
  }

  const previewLink = event.target.closest('.operation-photo-preview');
  if (previewLink) {
    if (!String(previewLink.getAttribute('href') || '').startsWith('data:image/')) return;
    event.preventDefault();
    openOperationPhoto(previewLink);
  }
});

const OPERATION_CLEANLINESS_LABELS = {
  limpo: 'Agradável (limpo)',
  sujeira_interna: 'Excesso de sujeira interna',
  sujeira_externa: 'Excesso de sujeira externa'
};

function renderOperationDetails(reserva) {
  const operacao = reserva.operacao || {};
  const encerramento = reserva.encerramentoAdministrativo;
  if (!operacao.retirada && !operacao.devolucao && !encerramento) return '';
  const renderPhase = (label, data) => {
    if (!data) return '';
    const photos = Array.isArray(data.fotos) ? data.fotos : [];
    const cleanlinessLabel = OPERATION_CLEANLINESS_LABELS[data.condicaoLimpeza];
    return '<div class="operation-record">' +
      '<strong>' + label + '</strong>' +
      '<span>Km ' + Number(data.quilometragem || 0).toLocaleString('pt-BR') + ' · Combustível: ' + escapeHTML(data.combustivel || '—') + '</span>' +
      (data.quilometragemDivergente ? '<span>⚠️ Quilometragem informada abaixo do esperado - verificar odômetro in loco</span>' : '') +
      (cleanlinessLabel ? '<span>Condição de limpeza: ' + escapeHTML(cleanlinessLabel) + '</span>' : '') +
      (data.avarias ? '<span>Avarias/observações: ' + escapeHTML(data.avarias) + '</span>' : '') +
      '<span>Registrado por ' + escapeHTML(data.registradoPor || '—') + ' em ' + escapeHTML(formatDateTime(data.registradoEm)) + '</span>' +
      (photos.length ? '<div class="operation-photos">' +
        photos.map((photo, index) => renderOperationPhoto(photo, index, label)).join('') +
        '</div>' : '') +
      '</div>';
  };
  const summaryText = reservationHasOperationReport(reserva)
    ? '⚠️ Ver avarias, fotos ou limpeza registradas'
    : 'Ver retirada e devolução';
  return '<details class="operation-details"><summary>' + summaryText + '</summary>' +
    renderPhase('Retirada', operacao.retirada) +
    renderPhase('Devolução', operacao.devolucao) +
    (encerramento ? '<div class="operation-record operation-record-administrative">' +
      '<strong>Encerramento administrativo</strong>' +
      '<span>Justificativa: ' + escapeHTML(encerramento.justificativa || '—') + '</span>' +
      '<span>Registrado por ' + escapeHTML(encerramento.registradoPor || '—') + ' em ' +
      escapeHTML(formatDateTime(encerramento.registradoEm)) + '</span>' +
      '</div>' : '') +
    '</details>';
}

function bindReservationFeatureButtons(container) {
  container.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      openSelfEditReservation(this.getAttribute('data-id'));
    });
  });
  container.querySelectorAll('.operation-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      if (this.getAttribute('data-pickup-info') === 'true') {
        const reservationId = this.getAttribute('data-id');
        const reservation = getReservations().find(item => String(item.id) === String(reservationId));
        if (reservation && canRegisterPickupNow(reservation)) {
          openOperationModal(reservationId, 'retirada');
        } else {
          openPickupAvailabilityModal(reservationId);
        }
        return;
      }
      openOperationModal(this.getAttribute('data-id'), this.getAttribute('data-phase'));
    });
  });
}

const pickupAvailabilityModal = document.getElementById('pickupAvailabilityModal');
const pickupAvailabilityDate = document.getElementById('pickupAvailabilityDate');
const pickupAvailabilitySummary = document.getElementById('pickupAvailabilitySummary');

function openPickupAvailabilityModal(reservationId) {
  const reservation = getReservations().find(item => String(item.id) === String(reservationId));
  if (!reservation) return;
  pickupAvailabilityDate.textContent = formatPickupAvailableFrom(reservation);
  pickupAvailabilitySummary.innerHTML = escapeHTML(reservation.partida + ' → ' + reservation.destino) +
    '<br>' + getVehicleDisplayHTML(reservation);
  pickupAvailabilityModal.classList.remove('hidden');
}

function closePickupAvailabilityModal() {
  pickupAvailabilityModal.classList.add('hidden');
}

document.getElementById('pickupAvailabilityCloseBtn').addEventListener('click', closePickupAvailabilityModal);
document.getElementById('pickupAvailabilityOkBtn').addEventListener('click', closePickupAvailabilityModal);
pickupAvailabilityModal.addEventListener('click', event => {
  if (event.target === pickupAvailabilityModal) closePickupAvailabilityModal();
});


// Quilometragem da devolução mais recente já registrada para um veículo
// (mesmo local + código), em qualquer reserva - não só a reserva atual.
// Usado para pré-preencher a retirada com o odômetro real deixado pela
// última pessoa que devolveu o carro. Ordena por "registradoEm" (o
// timestamp do próprio registro) em vez de data/horário da reserva, porque
// é o que reflete quando a devolução de fato aconteceu.
function lastVehicleDevolucaoKm(partida, carro, excludeReservationId){
  const candidatos = getReservations().filter(r =>
    String(r.id) !== String(excludeReservationId) &&
    r.partida === partida && String(r.carro) === String(carro) &&
    r.operacao && r.operacao.devolucao && r.operacao.devolucao.registradoEm
  );
  if (!candidatos.length) return null;
  candidatos.sort((a, b) =>
    new Date(b.operacao.devolucao.registradoEm) - new Date(a.operacao.devolucao.registradoEm));
  const km = Number(candidatos[0].operacao.devolucao.quilometragem);
  return Number.isFinite(km) ? km : null;
}

/* =========================================================
   Retirada e devolução
   ========================================================= */
const operationModal = document.getElementById('operationModal');
const operationForm = document.getElementById('operationForm');
const operationTitle = document.getElementById('operationTitle');
const operationSummary = document.getElementById('operationSummary');
const operationError = document.getElementById('operationError');
let operationReservationId = null;
let operationPhase = null;

async function openOperationModal(reservationId, phase) {
  const reserva = getReservations().find(r => String(r.id) === String(reservationId));
  const currentUser = getCurrentUser();
  if (!reserva || !currentUser || (reserva.nome !== currentUser.nome && !isAdmin())) return;
  const operacao = reserva.operacao || {};
  if ((phase === 'retirada' && operacao.retirada) || (phase === 'devolucao' && (!operacao.retirada || operacao.devolucao))) return;
  if (phase === 'retirada' && !canRegisterPickupNow(reserva)) {
    await showSiteAlert(
      'A retirada só pode ser registrada a partir de ' +
      formatPickupAvailableFrom(reserva) + '.',
      {
        title: 'Retirada ainda indisponível',
        type: 'info'
      }
    );
    return;
  }
  operationReservationId = reservationId;
  operationPhase = phase;
  operationForm.reset();
  operationError.textContent = '';
  document.getElementById('operationPhotoHint').textContent = '';
  operationTitle.textContent = phase === 'retirada' ? 'Registrar retirada' : 'Registrar devolução';
  operationSummary.innerHTML = escapeHTML(reserva.partida + ' → ' + reserva.destino) +
    '<br>' + getVehicleDisplayHTML(reserva);
  // Condição de limpeza é perguntada nas duas fases (retirada e devolução) -
  // o campo em si é sempre o mesmo select, então só falta garantir que ele
  // esteja visível e obrigatório de novo (reset() já limpa a seleção
  // anterior). O form usa "novalidate" porque a validação de verdade já é
  // feita manualmente no submit abaixo.
  document.getElementById('operationCleanlinessField').classList.remove('hidden');
  document.getElementById('operationCleanliness').required = true;
  document.getElementById('error-operationCleanliness').textContent = '';
  // Só um lembrete visual do valor esperado agora - não trava mais o campo
  // (min dinâmico), porque um dígito a mais digitado por engano deixava a
  // pessoa impedida de registrar a operação. Ver a confirmação de divergência
  // no submit, abaixo.
  const kmInput = document.getElementById('operationKm');
  const kmHint = document.getElementById('operationKmHint');
  if (phase === 'devolucao' && operacao.retirada) {
    kmHint.textContent = 'Quilometragem na retirada: ' + Number(operacao.retirada.quilometragem || 0).toLocaleString('pt-BR') + ' km.';
  } else {
    // Retirada: pré-preenche com a quilometragem da última devolução
    // registrada para este mesmo veículo (de qualquer reserva anterior) -
    // é o valor mais confiável disponível, porque reflete o odômetro real na
    // última vez que alguém devolveu o carro. "operationKm.value" continua
    // editável normalmente; isto é só um ponto de partida, não uma trava.
    const ultimaDevolucaoKm = lastVehicleDevolucaoKm(reserva.partida, reserva.carro, reservationId);
    if (ultimaDevolucaoKm != null) {
      kmInput.value = ultimaDevolucaoKm;
      kmHint.textContent = 'Preenchido com a quilometragem da última devolução deste veículo (' +
        ultimaDevolucaoKm.toLocaleString('pt-BR') + ' km) - confira antes de confirmar.';
    } else {
      const vehicle = getVehicle(reserva.partida, reserva.carro);
      kmHint.textContent = vehicle && vehicle.odometroAtual != null && vehicle.odometroAtual !== ''
        ? 'Odômetro atual do veículo: ' + Number(vehicle.odometroAtual).toLocaleString('pt-BR') + ' km.'
        : '';
    }
  }
  operationModal.classList.remove('hidden');
}

function closeOperationModal() {
  operationModal.classList.add('hidden');
  operationReservationId = null;
  operationPhase = null;
}

document.getElementById('operationCloseBtn').addEventListener('click', closeOperationModal);
operationModal.addEventListener('click', e => {
  if (e.target === operationModal) closeOperationModal();
});

document.getElementById('operationPhotos').addEventListener('change', function () {
  const count = Math.min(this.files.length, 3);
  document.getElementById('operationPhotoHint').textContent = count
    ? count + (count === 1 ? ' foto selecionada.' : ' fotos selecionadas.')
    : '';
});

function filesToDataUrls(files) {
  const selected = Array.from(files || []).slice(0, 3);
  return Promise.all(selected.map(file => new Promise((resolve, reject) => {
    if (file.size > 1024 * 1024) {
      reject(new Error('Cada foto deve ter no máximo 1 MB.'));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve({ nome: file.name, tipo: file.type, dados: reader.result });
    reader.onerror = () => reject(new Error('Não foi possível ler uma das fotos.'));
    reader.readAsDataURL(file);
  })));
}

operationForm.addEventListener('submit', async function (e) {
  e.preventDefault();
  // Busca bloqueios/reservas frescos antes de validar - mesmo raciocínio do
  // envio da reserva (ver js/reservations.js): sem isso, o odômetro atual do
  // veículo usado na comparação abaixo poderia estar desatualizado. Se a
  // atualização falhar, segue com os dados que já tinha - o servidor ainda é
  // quem valida de verdade no envio.
  try {
    await hydrateDatabaseState();
  } catch (error) {
    console.error('Falha ao atualizar dados antes de validar a operação:', error);
  }
  const list = getReservations();
  const idx = list.findIndex(r => String(r.id) === String(operationReservationId));
  if (idx === -1) return;
  const reserva = list[idx];
  if (operationPhase === 'retirada' && !canRegisterPickupNow(reserva)) {
    operationError.textContent =
      'A retirada só pode ser registrada a partir de ' +
      formatPickupAvailableFrom(reserva) + '.';
    return;
  }
  const km = Number(document.getElementById('operationKm').value);
  const fuel = document.getElementById('operationFuel').value;
  if (!Number.isFinite(km) || km < 0 || !fuel) {
    operationError.textContent = 'Informe quilometragem e combustível.';
    return;
  }
  const cleanlinessValue = document.getElementById('operationCleanliness').value;
  if (!cleanlinessValue) {
    document.getElementById('error-operationCleanliness').textContent = 'Selecione a condição de limpeza do veículo.';
    return;
  }
  document.getElementById('error-operationCleanliness').textContent = '';

  // Quilometragem menor que o esperado não bloqueia mais o registro (um
  // dígito a mais digitado por engano deixava a pessoa impedida de concluir a
  // retirada/devolução) - em vez disso, confirma com quem está preenchendo e,
  // se confirmado, avisa quem cuida da frota pra verificar o odômetro in loco
  // (ver server/notifications.js e server/validation.js).
  let quilometragemDivergente = false;
  if (operationPhase === 'devolucao' && reserva.operacao && reserva.operacao.retirada &&
    km < Number(reserva.operacao.retirada.quilometragem || 0)) {
    const confirmado = await showSiteConfirm(
      'A quilometragem informada · ' + km.toLocaleString('pt-BR') + ' km · é menor que a registrada na retirada: ' +
      Number(reserva.operacao.retirada.quilometragem).toLocaleString('pt-BR') + ' km. Confirma mesmo assim?',
      { title: 'Quilometragem menor que a retirada', confirmText: 'Confirmar' }
    );
    if (!confirmado) return;
    quilometragemDivergente = true;
  }
  if (operationPhase === 'retirada') {
    const vehicle = getVehicle(reserva.partida, reserva.carro);
    const odometroAtual = vehicle && vehicle.odometroAtual != null && vehicle.odometroAtual !== ''
      ? Number(vehicle.odometroAtual)
      : null;
    if (odometroAtual != null && km < odometroAtual) {
      const confirmado = await showSiteConfirm(
        'A quilometragem informada · ' + km.toLocaleString('pt-BR') + ' km · é menor que o odômetro atual do veículo: ' +
        odometroAtual.toLocaleString('pt-BR') + ' km. Confirma mesmo assim?',
        { title: 'Quilometragem menor que o odômetro do veículo', confirmText: 'Confirmar' }
      );
      if (!confirmado) return;
      quilometragemDivergente = true;
    }
  }

  try {
    const photos = await filesToDataUrls(document.getElementById('operationPhotos').files);
    reserva.operacao = reserva.operacao || {};
    reserva.operacao[operationPhase] = {
      quilometragem: km,
      combustivel: fuel,
      avarias: document.getElementById('operationDamages').value.trim(),
      // Perguntado nas duas fases (ver openOperationModal). "Excesso de
      // sujeira" conta como avaria/observação pra tudo que já reage a
      // avarias/fotos (filtro "Somente com registro", notificação ao
      // responsável) - ver reservationHasOperationReport em js/utils.js e
      // notifyOperationReport em server/notifications.js.
      condicaoLimpeza: cleanlinessValue || undefined,
      quilometragemDivergente: quilometragemDivergente || undefined,
      fotos: photos,
      registradoPor: getCurrentUser().nome,
      registradoEm: new Date().toISOString()
    };
    reserva.status = operationPhase === 'retirada' ? 'em uso' : 'concluída';
    list[idx] = reserva;
    await saveReservations(list);
    closeOperationModal();
    renderMyReservations();
    if (canManageReservations()) renderAdminTab();
    // Os indicadores da frota aparecem na mesma aba "Reservas" - sem isto,
    // km/concluídas ficavam desatualizados na tela até trocar de aba e voltar.
    if (typeof canViewReports === 'function' && canViewReports() && typeof renderIndicators === 'function') renderIndicators();
  } catch (error) {
    operationError.textContent = error.message;
  }
});

